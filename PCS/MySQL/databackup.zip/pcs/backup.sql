CREATE DATABASE  IF NOT EXISTS `pcs` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pcs`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: pcs
-- ------------------------------------------------------
-- Server version	5.6.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cell`
--

DROP TABLE IF EXISTS `cell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `blockId` int(11) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `cell_blockId_idx` (`blockId`),
  CONSTRAINT `cell_blockId` FOREIGN KEY (`blockId`) REFERENCES `cell_block` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cell`
--

LOCK TABLES `cell` WRITE;
/*!40000 ALTER TABLE `cell` DISABLE KEYS */;
INSERT INTO `cell` VALUES (1,'101',2,'GF'),(2,'102',2,'GF'),(3,'101',1,'GF'),(4,'1001',3,'BS'),(5,'2001',4,'BS');
/*!40000 ALTER TABLE `cell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cell_block`
--

DROP TABLE IF EXISTS `cell_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cell_block` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `prisonId` int(11) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `cellBlock_prisonId.fk_idx` (`prisonId`),
  CONSTRAINT `cellBlock_prisonId.fk` FOREIGN KEY (`prisonId`) REFERENCES `prison` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cell_block`
--

LOCK TABLES `cell_block` WRITE;
/*!40000 ALTER TABLE `cell_block` DISABLE KEYS */;
INSERT INTO `cell_block` VALUES (1,'A',1,'Where bad people go.'),(2,'B',1,'Where really bad people go.'),(3,'One',2,'Pedophiles'),(4,'Two',2,'Tax Evaders');
/*!40000 ALTER TABLE `cell_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_cataloger`
--

DROP TABLE IF EXISTS `data_cataloger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_cataloger` (
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `fName` varchar(45) NOT NULL,
  `lName` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `sex` varchar(1) DEFAULT NULL,
  `doB` date DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_cataloger`
--

LOCK TABLES `data_cataloger` WRITE;
/*!40000 ALTER TABLE `data_cataloger` DISABLE KEYS */;
INSERT INTO `data_cataloger` VALUES ('datacat','datacat','John','Doe','johndoe@email.com','M','1985-02-05');
/*!40000 ALTER TABLE `data_cataloger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dba`
--

DROP TABLE IF EXISTS `dba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dba` (
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `fName` varchar(45) NOT NULL,
  `lName` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `sex` varchar(1) DEFAULT NULL,
  `doB` date DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dba`
--

LOCK TABLES `dba` WRITE;
/*!40000 ALTER TABLE `dba` DISABLE KEYS */;
INSERT INTO `dba` VALUES ('dba','dba','Dave','Computer','dba@email.com','M','1980-03-28');
/*!40000 ALTER TABLE `dba` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lives_in`
--

DROP TABLE IF EXISTS `lives_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lives_in` (
  `prisonerId` int(11) NOT NULL,
  `cellId` int(11) NOT NULL,
  PRIMARY KEY (`prisonerId`),
  UNIQUE KEY `prisonerId_UNIQUE` (`prisonerId`),
  KEY `livesIn_cellId.fk_idx` (`cellId`),
  CONSTRAINT `livesIn_prisonerId.fk` FOREIGN KEY (`prisonerId`) REFERENCES `prisoner` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `livesIn_cellId.fk` FOREIGN KEY (`cellId`) REFERENCES `cell` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lives_in`
--

LOCK TABLES `lives_in` WRITE;
/*!40000 ALTER TABLE `lives_in` DISABLE KEYS */;
INSERT INTO `lives_in` VALUES (3,1),(2,4),(1,5),(4,5);
/*!40000 ALTER TABLE `lives_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offense`
--

DROP TABLE IF EXISTS `offense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offense` (
  `offenseId` int(11) NOT NULL AUTO_INCREMENT,
  `prisonerId` int(11) NOT NULL,
  `location` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`offenseId`),
  UNIQUE KEY `offenseId_UNIQUE` (`offenseId`),
  KEY `offense_prisonerId.fk_idx` (`prisonerId`),
  CONSTRAINT `offense_prisonerId.fk` FOREIGN KEY (`prisonerId`) REFERENCES `prisoner` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offense`
--

LOCK TABLES `offense` WRITE;
/*!40000 ALTER TABLE `offense` DISABLE KEYS */;
INSERT INTO `offense` VALUES (1,1,'Grand Forks','Felony','Did a really bad thing!','2013-05-24'),(2,2,'Langdon','Misdemeanor','Rocked too hard','2014-01-01'),(3,3,'Bismarck','Felony','Drove much too fast','2012-08-23'),(4,4,'Ellendale','Felony','Wrongly convicted','2014-04-02');
/*!40000 ALTER TABLE `offense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prison`
--

DROP TABLE IF EXISTS `prison`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prison` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prison`
--

LOCK TABLES `prison` WRITE;
/*!40000 ALTER TABLE `prison` DISABLE KEYS */;
INSERT INTO `prison` VALUES (1,'Grand Forks County Jail','Grand Forks, ND'),(2,'North Dakota State Penitentiary','Bismarck, ND');
/*!40000 ALTER TABLE `prison` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prisoner`
--

DROP TABLE IF EXISTS `prisoner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prisoner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prisonId` int(11) NOT NULL,
  `fName` varchar(45) NOT NULL,
  `lName` varchar(45) NOT NULL,
  `doB` date DEFAULT NULL,
  `sex` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `prisoner_prisonId.fk_idx` (`prisonId`),
  CONSTRAINT `prisoner_prisonId.fk` FOREIGN KEY (`prisonId`) REFERENCES `prison` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prisoner`
--

LOCK TABLES `prisoner` WRITE;
/*!40000 ALTER TABLE `prisoner` DISABLE KEYS */;
INSERT INTO `prisoner` VALUES (1,1,'Ben','Carpenter','1990-12-31','M'),(2,2,'Randall','Howatt','1990-12-31','M'),(3,2,'Alex','Lewis','1990-12-31','M'),(4,1,'Michael','Schilling','1992-06-03','M');
/*!40000 ALTER TABLE `prisoner` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-04  9:12:31
